/* Практическая работа. 
Сделать так чтобы emitter.listenerCount(eventName) вывел значения:
    15
    9
    1 
*/

const EventEmitter = require("events");
// определяем эмиттер событий
const emitter = new EventEmitter();
 
// Добавляем 15 обработчиков для события 'eventA'
for (let i = 0; i < 15; i++) {
    emitter.on('eventA', () => {
        console.log(`eventA`);
    });
}

// Добавляем 9 обработчиков для события 'eventB'
for (let i = 0; i < 9; i++) {
    emitter.on('eventB', () => {
        console.log(`eventB`);
    });
}

// Добавляем 1 обработчик для события 'eventC'
emitter.on('eventC', () => {
    console.log('eventC');
});

// Проверяем количество обработчиков для каждого события
console.log(emitter.listenerCount('eventA')); // Выведет: 15
console.log(emitter.listenerCount('eventB')); // Выведет: 9
console.log(emitter.listenerCount('eventC')); // Выведет: 1